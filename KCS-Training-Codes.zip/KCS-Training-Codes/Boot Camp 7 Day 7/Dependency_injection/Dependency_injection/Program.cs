﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace Dependency_injection
{
    enum Months
    {
        Jan = 1,
        Feb,
        Mar,
        Apr = 20,
        May,
        Jun,
        Jul,
        Aug,
        Sep,
        Oct,
        Nov,
        Dec
    }

    public interface I1
    {
        void Demo();
    }

    
    class Child1 : I1
    {
        public void Demo()
        {
            Console.WriteLine("Demo Function Called of Child1 Class - Constructor Injection.");
        }
    }

   
    class Child2 : I1
    {
        public void Demo()
        {
            Console.WriteLine("Demo Function Called of Child2 Class - Constructor Injection.");
        }
    }

   
    public class ConstructorInjection
    {
        private I1 _i1;

        public ConstructorInjection(I1 _i1)
        {
            this._i1 = _i1;
        }
        public void Demo()
        {
            _i1.Demo();
        }
    }


    #region Property Injection.
    // Interface I2 - To manage Property Injection..
    public interface I2
    {
        void DemoPropertyInjection(string message);
    }

    class LogWriterClass : I2
    {
        public void DemoPropertyInjection(string message)
        {
            Console.WriteLine("DemoPropertyInjection Method Called of LogWriterClass - Property Injection.");
        }
    }
    class LogWriterClass2 : I2
    {
        public void DemoPropertyInjection(string message)
        {
            Console.WriteLine("DemoPropertyInjection Method Called of LogWriterClass2 - Property Injection.");
        }
    }
    class PropertyInjectionClass
    {
        I2 _i2 = null;
        public void DemoPropertyInjectionFunctionOfClass(I2 _i2, string messages)
        {
            this._i2 = _i2;
            _i2.DemoPropertyInjection(messages);
        }
    }

    #endregion

    #region Method Injection.

    // Interface I3 - Method Injection Demo.
    public interface I3
    {
        void Demo3();
    }

    // Service Class
    public class ServiceClass : I3
    {
        public void Demo3()
        {
            Console.WriteLine("Demo3 Method Overriding - Service Class.");
        }
    }

    // Client Class
    public class ClientClass
    {
        private I3 _i3;
        public void ClientClassMethod(I3 _i3)
        {
            this._i3 = _i3;
            Console.WriteLine("Client Class Method Statement Called.");
            this._i3.Demo3();
        }
    }



    #endregion


    public class constant
    {
        public const int a = 10;
        readonly int b = 10;
        int c= 20;
        public  constant(int n)
        {
            b = n;
        }
    }

    internal class Program

    {
        public void DemoExceptional()
        {
            try
            {
                int a = 100;
                Console.WriteLine("Value of a is:" + a);
            }
            catch (Exception E)
            {
                Console.WriteLine(E.Message);
            }
            finally
            {
                Console.WriteLine("Finally");
            }
        }
        public const int a = 10;
        readonly int b = 10;
        int c = 20;

        public Program(int n)
        {
            b = n;
        }
        static void Main(string[] args)


        {
            Program P = new Program(10);

            Console.WriteLine(P.b);
            P.c = 100;

            #region Construtor Injection.
            //Reference variable of ConstructorInjection Class.
            ConstructorInjection cs = null;

            // Initialize ConstructorInjection Class Reference with Child1 Class Object.
            cs = new ConstructorInjection(new Child1());
            // Call Child1 Class Demo Function.
            cs.Demo();

            // Initialize ConstructorInjection Class Reference with Child2 Class Object.
            cs = new ConstructorInjection(new Child2());
            // Call Child2 Class Demo Function.
            cs.Demo();
            #endregion

            #region Property Injection.
            // PropertyInjectionClass Object Creates.
            PropertyInjectionClass PIC = new PropertyInjectionClass();

            // DemoPropertyInjectionFunctionOfClass() Method Called by using PropertyInjectionClass Object & LogWritterClass Passed as an Object + Message Property Value Passed.
            PIC.DemoPropertyInjectionFunctionOfClass(new LogWriterClass(), "Message - Property Value Passed.");
            PIC.DemoPropertyInjectionFunctionOfClass(new LogWriterClass2(), "Message - Property Value Passed.");
            #endregion

            #region Method Injection.
            // Client Class Object Create.
            ClientClass CCLS = new ClientClass();
            // ClientClassMethod with ServiceClass Object as an Argument.
            CCLS.ClientClassMethod(new ServiceClass());
            #endregion


            #region NonGenerics Collection

            ArrayList ArrL = new ArrayList();
            Queue Q = new Queue();
            Stack S = new Stack();

            ArrL.Add("Rishit");
            ArrL.Add(10);

            foreach (Object O in ArrL)
            {
                Console.WriteLine(O);
            }

            Q.Enqueue("Rishit");
            Q.Enqueue(100);

            foreach (Object O in Q)
            {
                Console.WriteLine(O);
            }

            S.Push("Rishit");
            S.Push(100);
            foreach (Object O in S)
            {
                Console.WriteLine(O);
            }

            #endregion

            #region Generics Collection

            List<Int32> IntegerGenericsExm = new List<Int32>();
            IntegerGenericsExm.Add(10);
            IntegerGenericsExm.AddRange(new int[] { 20, 30, 40, 50 });

            foreach (int I in IntegerGenericsExm)
            {
                Console.WriteLine(I);
            }


            #endregion

            Console.WriteLine(Convert.ToInt32(Months.May) + 11);
            Console.ReadKey();
        }
    }
}
