function demoExternalAlert(){
    alert("hello shivam")
}
function demoExternalConfirm(){
    confirm('is shivam veg?')
}

function demoExternalPrompt(){
    prompt('is yash veg?')
}

function bodyBGGreen(){
    document.body.style.backgroundColor="purple";

}
function divBGGray(){
    document.getElementById('div').style.backgroundColor='yellow'
}
function bodyBGDynamic(){
    document.body.style.backgroundColor=prompt("enter color");
}
function divBGDynamic(){
    document.getElementById("div").style.backgroundColor=prompt("Enter color name here..");
}
function bodyBGCP1(){
    document.body.style.backgroundColor=document.getElementById("CP1").value;
}
function divBGCP2(){
    document.body.style.backgroundColor=document.getElementById("CP2").value;
}
