﻿using System;

namespace ConsoleApp1
{
    public class Employee
    {
        public float salary = 40000;
    }
    public class Programmer : Employee
    {
        public float bonus = 10000;
    }





    class animal
    {



        public void animalsound()
        {



            Console.WriteLine("animal makes sound");



        }
    }



    class dog : animal
    {



        public void animalsound()
        {



            Console.WriteLine("dog barks");



        }
    }



    class bird : animal
    {
        public void animalsound()
        {



            Console.WriteLine("bird sound");
        }



    }





    // Abstract class
    abstract class Animal
    {
        // Abstract method (does not have a body)
        public abstract void animalSound();
        // Regular method
        public void sleep()
        {
            Console.WriteLine("Zzz");
        }
    }



    // Derived class (inherit from Animal)
    class Pig : Animal
    {
        public override void animalSound()
        {
            // The body of animalSound() is provided here
            Console.WriteLine("The pig says: wee wee");
        }
    }




    class baseClass



    {
        public void show()
        {
            Console.WriteLine("Base class");
        }
    }



    // derived class name 'derived'
    // 'baseClass' inherit here
    class derived : baseClass
    {



        // overriding
        new public void show()
        {
            Console.WriteLine("Derived class");
        }
    }



    class oberload
    {



        public int add(int a, int b, int c)
        {
            int sum = a + b + c;



            return sum;
        }



        public double add(double a, double b, double c)
        {




            double sum = a + b + c;
            return sum;

        }
    }




    //interface
    interface human
    {



        public void talk();
        public void walk();
    }
    class humanactivity : human
    {
        public void talk()
        {



            Console.WriteLine("human talk");

        }



        public void walk()



        {
            Console.WriteLine("human walk");

        }
        public void run()
        {



            Console.WriteLine("human running");
        }



    }



    //demo encapulation



    public class encapulatiodemo
    {



        private String Studentname;
        private int StudentAge;



        public String name
        {



            get { return Studentname; }




            set { Studentname = value; }
        }

        public int age
        {
            get { return StudentAge; }
            set { StudentAge = value; }
        }







    }




    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.WriteLine("Hello World!");
            Programmer p1 = new Programmer();
            Console.WriteLine(p1.salary);
            Console.WriteLine(p1.bonus);



            //polumophisam
            animal a = new animal();
            animal dog = new dog();
            animal birdd = new bird();



            a.animalsound();
            dog.animalsound();
            birdd.animalsound();



            //abstraction
            Pig myPig = new Pig();
            myPig.animalSound();
            myPig.sleep();





            //overriding
            baseClass obj = new baseClass();



            obj.show();
            obj = new derived();
            obj.show();



            //overloading
            oberload o = new oberload();
            int sum1 = o.add(1, 2, 3);
            double sum2 = o.add(1.5, 2.5, 3.5);
            Console.WriteLine("double value:" + sum2);
            Console.WriteLine("int value" + sum1);




            //interface
            humanactivity h = new humanactivity();
            h.talk();
            h.walk();
            h.run();



            //encapulationdemo



            encapulatiodemo enp1 = new encapulatiodemo();
            enp1.age = 22;
            enp1.name = "tarun";
            Console.WriteLine("name:" + enp1.name);
            Console.WriteLine("age is:" + enp1.age);




        }
    }
}
